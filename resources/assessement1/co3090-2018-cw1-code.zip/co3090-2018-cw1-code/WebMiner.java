package uk.ac.le.cs.CO3090.cw1;


public class WebMiner implements Runnable {
	 
	public static int MAX_MINER_NUM=10;
	@Override
	public void run() {
	}

	/**
	 * void mine(String URL) 
	 * 
	 * this method should record:
	 * 
	 *  (1) All pages it visited  marks a URL as 'visited' by 
	 *      adding it to 'visited' list
	 *  
	 *  (2) total keyword counts  
	 *  
	 *  (3) keyword frequency for every page it visited (case-insensitive) 
	 *      
	 *  (4) keyword frequency for all pages it visited (case-insensitive) 
	 *  
	 *  Note: skip URLs that have been visited by other miners 
	 * 
	 * @param URL
	 * @throws InterruptedException
	 */
	public void mine(String URL) throws InterruptedException{
	}

	
	public static void main(String[] args){
		
	}

}
