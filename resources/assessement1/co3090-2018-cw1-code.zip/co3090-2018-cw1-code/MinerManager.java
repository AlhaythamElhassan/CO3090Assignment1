package uk.ac.le.cs.CO3090.cw1;


public class MinerManager implements Runnable{
	
	 public static int MAX_PAGES_NUM=50; 
	 public static int TIME_OUT=20;
	 public static int MAX_QUEUE_SIZE=20000;
	 public static int MAX_WORD_COUNT=100000;
	 
	 
	@Override
	public void run() {
	
	}
	
	
	
//	 * The output should look like:
//	 
//	 ============
//		Total number of keywords:91
//		Pages visited:43
//      Pending pages no visited yet: 67 
//	
//		University = 25
//		Britain = 473
//		Brexit = 130
//		Holidays = 102
//      Sports = 34	
//	 =============
//	    
//	
//	 *The results may vary depending on your 
//	 *search strategy.	 
//	 *               
//	 * @throws InterruptedException
//	 * @return   
//	 */
	public void showTotalStatistics()throws InterruptedException {
	}
	
	
}
